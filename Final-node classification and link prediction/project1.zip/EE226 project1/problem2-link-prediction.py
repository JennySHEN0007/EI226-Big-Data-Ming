import stellargraph as sg

try:
    sg.utils.validate_notebook_version("1.2.1")
except AttributeError:
    raise ValueError(
        f"This notebook requires StellarGraph version 1.2.1, but a different version {sg.__version__} is installed.  Please see <https://github.com/stellargraph/stellargraph/issues/1172>."
    ) from None



import matplotlib.pyplot as plt
from math import isclose
from sklearn.decomposition import PCA
import os
import networkx as nx
import numpy as np
import pandas as pd
from stellargraph import StellarGraph, datasets
from stellargraph.data import EdgeSplitter
from collections import Counter
import multiprocessing
# from IPython.display import display, HTML
from sklearn.model_selection import train_test_split

# %matplotlib inline


edges = pd.read_csv("/Users/tza991101/Desktop/2021Spring/大数据挖掘/project/problem2/dataset after preprocessing/edges.csv")



from stellargraph import StellarGraph
g = StellarGraph(
    edges=edges, node_type_default="author", edge_type_default="co-work"
)
print(g.info())



# Define an edge splitter on the original graph:
edge_splitter_test = EdgeSplitter(g)

# Randomly sample a fraction p=0.1 of all positive links, and same number of negative links, from graph, and obtain the
# reduced graph graph_test with the sampled links removed:
graph_test, examples_test, labels_test = edge_splitter_test.train_test_split(
    p=0.00001, method="global"
)

print(graph_test.info())



# Do the same process to compute a training subset from within the test graph
edge_splitter_train = EdgeSplitter(graph_test, g)
graph_train, examples, labels = edge_splitter_train.train_test_split(
    p=0.1, method="global"
)
(
    examples_train,
    examples_model_selection,
    labels_train,
    labels_model_selection,
) = train_test_split(examples, labels, train_size=0.75, test_size=0.25)

print(graph_train.info())



df1 = pd.DataFrame(
    [
        (
            "Training Set",
            len(examples_train),
            "Train Graph",
            "Test Graph",
            "Train the Link Classifier",
        ),
        (
            "Model Selection",
            len(examples_model_selection),
            "Train Graph",
            "Test Graph",
            "Select the best Link Classifier model",
        ),
        (
            "Test set",
            len(examples_test),
            "Test Graph",
            "Full Graph",
            "Evaluate the best Link Classifier",
        ),
    ],
    columns=("Split", "Number of Examples", "Hidden from", "Picked from", "Use"),
).set_index("Split")

print(df1)



p = 0.5
q = 0.5
dimensions = 128
num_walks = 1
walk_length = 80
window_size = 10
num_iter = 50
workers = multiprocessing.cpu_count()



from stellargraph.data import BiasedRandomWalk
from gensim.models import Word2Vec

from gensim.models.callbacks import CallbackAny2Vec


# from gensim.models import Word2Vec
# from gensim.models.word2vec import LineSentence
# from gensim.models.callbacks import CallbackAny2Vec

# class callback(CallbackAny2Vec):
#     '''Callback to print loss after each epoch.'''
#
#     def __init__(self):
#         self.epoch = 0
#         self.loss_to_be_subed = 0
#
#     def on_epoch_end(self, model):
#         loss = model.get_latest_training_loss()
#         loss_now = loss - self.loss_to_be_subed
#         self.loss_to_be_subed = loss
#         print('Loss after epoch {}: {}'.format(self.epoch, loss_now))
#         self.epoch += 1
#
# model = Word2Vec(LineSentence('./data/house_list'), size=100, workers=20, \
#                     min_count=1, iter=30, window=5, compute_loss=True, callbacks=[callback()])
# model.save('./model/v2.model')



class LossLogger(CallbackAny2Vec):
    '''Output loss at each epoch'''
    def __init__(self):
        self.epoch = 0
        self.loss_to_be_subed = 0
        self.losses = []


    def on_epoch_end(self, model):
        loss = model.get_latest_training_loss()
        loss_now = loss - self.loss_to_be_subed
        self.loss_to_be_subed = loss
        print('Loss after epoch {}: {}'.format(self.epoch, loss_now))
        self.epoch += 1
        self.losses.append(loss_now)


loss_logger = LossLogger()


def node2vec_embedding(graph, name):
    rw = BiasedRandomWalk(graph)
    walks = rw.run(graph.nodes(), n=num_walks, length=walk_length, p=p, q=q)
    print(f"Number of random walks for '{name}': {len(walks)}")

    model = Word2Vec(
        walks,
        vector_size=dimensions,
        window=window_size,
        min_count=0,
        compute_loss=True,
        callbacks=[loss_logger],
        sg=1,
        workers=workers,
        epochs=num_iter,
    )

    def get_embedding(u):
        return model.wv[u]

    return get_embedding, loss_logger.losses



embedding_train, embedding_train_losses = node2vec_embedding(graph_train, "Train Graph")

data = np.array(embedding_train_losses)
np.save("embedding_train_losses", data)

e = range(50)
plt.plot(e, embedding_train_losses)
plt.xlabel('Epoch number')
plt.ylabel('Loss')
plt.title('word2vec training losses')
plt.show()
plt.savefig('word2vec training losses')




from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler


# 1. link embeddings
def link_examples_to_features(link_examples, transform_node, binary_operator):
    return [
        binary_operator(transform_node(src), transform_node(dst))
        for src, dst in link_examples
    ]


# 2. training classifier
def train_link_prediction_model(
    link_examples, link_labels, get_embedding, binary_operator
):
    clf = link_prediction_classifier()
    link_features = link_examples_to_features(
        link_examples, get_embedding, binary_operator
    )
    clf.fit(link_features, link_labels)
    return clf


def link_prediction_classifier(max_iter=2000):
    lr_clf = LogisticRegressionCV(Cs=10, cv=10, scoring="roc_auc", max_iter=max_iter)
    return Pipeline(steps=[("sc", StandardScaler()), ("clf", lr_clf)])


# 3. and 4. evaluate classifier
def evaluate_link_prediction_model(
    clf, link_examples_test, link_labels_test, get_embedding, binary_operator
):
    link_features_test = link_examples_to_features(
        link_examples_test, get_embedding, binary_operator
    )
    score = evaluate_roc_auc(clf, link_features_test, link_labels_test)
    return score


def evaluate_roc_auc(clf, link_features, link_labels):
    predicted = clf.predict_proba(link_features)

    # check which class corresponds to positive links
    positive_column = list(clf.classes_).index(1)
    return roc_auc_score(link_labels, predicted[:, positive_column])



def operator_hadamard(u, v):
    return u * v


def operator_l1(u, v):
    return np.abs(u - v)


def operator_l2(u, v):
    return (u - v) ** 2


def operator_avg(u, v):
    return (u + v) / 2.0


def run_link_prediction(binary_operator):
    clf = train_link_prediction_model(
        examples_train, labels_train, embedding_train, binary_operator
    )
    score = evaluate_link_prediction_model(
        clf,
        examples_model_selection,
        labels_model_selection,
        embedding_train,
        binary_operator,
    )

    return {
        "classifier": clf,
        "binary_operator": binary_operator,
        "score": score,
    }


binary_operators = [operator_hadamard, operator_l1, operator_l2, operator_avg]



results = [run_link_prediction(op) for op in binary_operators]
best_result = max(results, key=lambda result: result["score"])

print(f"Best result from '{best_result['binary_operator'].__name__}'")

df2 = pd.DataFrame(
    [(result["binary_operator"].__name__, result["score"]) for result in results],
    columns=("name", "ROC AUC score"),
).set_index("name")

print(df2)



embedding, embedding_losses = node2vec_embedding(g, "Graph")

data = np.array(embedding_losses)
np.save("embedding_losses", data)



binary_operator = best_result['binary_operator']
author_pairs_to_pred = pd.read_csv('/Users/tza991101/Desktop/2021Spring/大数据挖掘/project/problem2/ee226-2021spring-problem2/author_pairs_to_pred_with_index.csv')
link_to_pred = author_pairs_to_pred['author_pair'].values
arr = link_to_pred[0].split()
arr = [int(k) for k in arr]
arr = np.array(arr, ndmin=2)
for i in range(1, len(link_to_pred)):
    x = link_to_pred[i].split()
    x = [int(k) for k in x]
    x = np.array(x, ndmin=2)
    arr = np.append(arr, x, axis=0)

link_to_pred = arr

transform_node = embedding
link_features = [binary_operator(transform_node(src), transform_node(dst)) for src, dst in link_to_pred]
clf = best_result["classifier"]
predicted = clf.predict_proba(link_features)



positive_column = list(clf.classes_).index(1)
predicted = predicted[:, positive_column]



label = pd.DataFrame(predicted, columns=['label'])

ids = list(range(10536))
ids = pd.DataFrame(ids, columns=['id'])

result = pd.concat([ids, label], axis=1)

result.to_csv('/Users/tza991101/Desktop/2021Spring/大数据挖掘/project/problem2/pred.csv', index=None)
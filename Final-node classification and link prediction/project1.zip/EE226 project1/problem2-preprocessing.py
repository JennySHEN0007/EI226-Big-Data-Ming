author_paper = pd.read_csv("../input/ee226-project-dataset/author_paper_all_with_year.csv")
paper_reference = pd.read_csv("../input/ee226-project-dataset/paper_reference.csv")

a_id=author_paper['author_id'].tolist()
p_id=author_paper['paper_id'].tolist()
p1_id=paper_reference['paper_id'].tolist()
r_id=paper_reference['reference_id'].tolist()
author1=[]
author2=[]

for j in range(len(list(set(p_id)))):
    tmp=[]
    for i in range(len(p_id)):
        if p_id[i]==j:
            tmp.append(a_id[i])
    for i in range(len(p1_id)):
        if p1_id[i]==j:
            for l in range(len(p_id)):
                if p_id[l]==r_id[i]:
                    tmp.append(a_id[l])
    cc = list(itertools.combinations(tmp, 2))
    for k in range(len(cc)):
        author1.append(cc[k][0])
        author2.append(cc[k][1])
        

source = author1
target = author2

edges = pd.DataFrame(
    {"source": source, "target": target}
)


edges = edges.sort_values(by=['source', 'target'], ignore_index=True)
edges = edges.drop_duplicates(ignore_index=True)

edges1=edges.rename(columns = {'target' : 'source', 'source' : 'target'})
edge = edges.append(edges1, ignore_index=True)
edge_dup = edge.duplicated()

for i in range(edges.shape[0], edge.shape[0]):
    if edge.loc[i, 'source'] > edge.loc[i, 'target']:
        edge_dup[i] = False
        
index = edge_dup.index
condition = edge_dup == True
indices = index[condition]
indices_list = indices.tolist()
new_list = [x-edges.shape[0] for x in indices_list]

edges = edges.drop(new_list)
edges = edges.reset_index(drop=True)

edges.to_csv('./author-author.csv', index=None)



missing = []
for i in range(42614):
    if i not in edges.values:
        missing.append(i)

missing = pd.DataFrame(missing,columns=['source'])
missing['target'] = missing['source']

missing.to_csv('./missing.csv', index=None)

frames = [edges, missing]
result = pd.concat(frames)

result.to_csv('./edges.csv', index=None)